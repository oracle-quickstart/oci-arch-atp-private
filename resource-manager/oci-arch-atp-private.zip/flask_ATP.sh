## Copyright (c) 2020, Oracle and/or its affiliates. 
## All rights reserved. The Universal Permissive License (UPL), Version 1.0 as shown at http://oss.oracle.com/licenses/upl

export LD_LIBRARY_PATH=/usr/lib/oracle/18.3/client64/lib
python3 /tmp/flask_ATP.py 